{
    graphitePort: 2003,
    graphiteHost: "localhost",
    port: 8125,
    flushInterval: 1000
}
