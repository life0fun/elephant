{
    graphitePort: 2003,
    graphiteHost: "cte-db3",
    port: 8125,
    flushInterval: 1000
}
