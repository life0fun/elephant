{
    graphitePort: 2003,
    graphiteHost: "vci-lm-graphite1",
    port: 8125,
    flushInterval: 1000
}
