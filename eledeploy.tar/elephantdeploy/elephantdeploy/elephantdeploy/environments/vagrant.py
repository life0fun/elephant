""" Elephant vagrant environment definition file. """

hosts = [
    'elephant-vagrant'
]

roledefs = {
    'elephant': hosts,
}
