""" Elephant stable environment definition file. """

hosts = [
    'elephant-stable',
]

roledefs = {
    'elephant': hosts,
}
