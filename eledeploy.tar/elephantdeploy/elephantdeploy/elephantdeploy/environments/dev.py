""" Elephant dev environment definition file. """

hosts = [
    'elephant-dev',
]

roledefs = {
    'elephant': hosts,
}
