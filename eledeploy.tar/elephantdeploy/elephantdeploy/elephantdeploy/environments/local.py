""" Elephant local environment definition file. """

hosts = [
    'localhost'
]

roledefs = {
    'database': hosts,
}
