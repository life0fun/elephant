keepalivedcore = {
    "network": {
        'ipaddress': '172.26.164.102',
        'private_ipaddress': '10.101.101.2',
    }
}
