keepalivedcore = {
    "network": {
        'ipaddress': '10.109.204.2',
        'private_ipaddress': '172.16.0.2',
    }
}
