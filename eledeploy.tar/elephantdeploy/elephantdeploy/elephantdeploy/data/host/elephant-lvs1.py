keepalivedcore = {
    "network": {
        'ipaddress': '10.109.204.1',
        'private_ipaddress': '172.16.0.1',
    }
}
