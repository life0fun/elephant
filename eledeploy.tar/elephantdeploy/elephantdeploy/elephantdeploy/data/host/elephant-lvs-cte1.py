keepalivedcore = {
    "network": {
        'ipaddress': '172.26.164.101',
        'private_ipaddress': '10.101.101.1',
    }
}
