""" Default configuration for nagios role. """

nagios = {
    'elephant_check_uri': '/api/1/',
    'auth': 'default:secret',
}
